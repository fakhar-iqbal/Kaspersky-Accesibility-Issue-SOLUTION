@echo off
title Safe Kid - Security Setup
color 0A

echo ===================================================
echo             SAFE KID - SECURITY SETUP
echo ===================================================
echo.
echo 1. Plug the child's phone into this computer using a USB cable.
echo 2. Unlock the phone screen.
echo 3. Ensure "USB Debugging" is enabled in Developer Options.
echo.
echo Press any key when the phone is plugged in and unlocked...
pause >nul

echo.
echo Connecting to phone... (If a prompt appears on the phone, tap "Allow")
adb.exe wait-for-device

echo.
echo Device connected! Applying master security permissions...
adb.exe shell pm grant com.kaspersafe.app android.permission.WRITE_SECURE_SETTINGS

echo.
echo ===================================================
echo SUCCESS! 
echo The engine is now armed. You may unplug the phone 
echo and open the Safe Kid app.
echo ===================================================
echo.
pause